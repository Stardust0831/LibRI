#!/usr/bin/env python3
from pathlib import Path
import array
import csv
import hashlib
import json
import math
import os
import shlex
import statistics
import subprocess
import sys
import threading
import time

root = Path(__file__).resolve().parent.parent
control = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'performance17-control'))
from common import binary_identity, setup, verify_sources
from benchmark_common import gpu_monitor

out = root / ('performance17-micro-results-' + os.environ['SLURM_JOB_ID'])
setup(out, 4)
(out / 'control-sha256.json').write_text(json.dumps({
    p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in control.iterdir() if p.is_file()
}, indent=2) + '\n')
deps = root.parent / 'lcao-hse/exx-device-20261018-3/build/hse-deps'
ddla = root.parent / 'lcao-hse/exx-device-20261018-3/install/ddla'
steps = []

def command(name, cmd, cwd=root, timeout=1800):
    cmd = list(map(str, cmd))
    dest = out / name
    dest.mkdir(parents=True)
    (dest / 'command.txt').write_text(shlex.join(cmd) + '\n')
    print('START', name, flush=True)
    start = time.monotonic()
    with (dest / 'output.log').open('wb') as log:
        result = subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    row = dict(name=name, command=cmd, returncode=result.returncode, seconds=time.monotonic()-start)
    steps.append(row)
    (out / 'steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    print('END', name, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name)

binaries = {}
for source in ['master', 'pr17', 'pr17-suggestions']:
    build = root / ('performance17-micro-build-' + source)
    command(source + '/configure', ['cmake', '-S', control, '-B', build,
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_FLAGS_RELEASE=-O3 -DNDEBUG',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', f'-DLIBRI_ROOT={root/source}',
            f'-DLIBCOMM_ROOT={deps}/libcomm', f'-DCEREAL_ROOT={deps}/cereal-install',
            f'-DDDLA_ROOT={ddla}', '-DBLA_VENDOR=OpenBLAS',
            '-DBENCH_RESIDENCY=' + ('OFF' if source == 'master' else 'ON')])
    command(source + '/build', ['cmake', '--build', build, '--verbose', '-j', '2'])
    commands = (build / 'compile_commands.json').read_text()
    assert '-O3' in commands and '-DNDEBUG' in commands and '-O0' not in commands
    (out / source / 'compile_commands.json').write_text(commands)
    (out / source / 'CMakeCache.txt').write_text((build / 'CMakeCache.txt').read_text())
    for scalar in ['real', 'complex']:
        binary = build / ('benchmark_' + scalar)
        binaries[(source, scalar)] = binary
        (out / source / (scalar + '-identity.json')).write_text(json.dumps(binary_identity(binary), indent=2) + '\n')

def run_case(name, source, scalar, resident, dimensions, measured=5, warmup=2):
    work = out / name
    work.mkdir(parents=True)
    cmd = ['mpirun', '-np', '1', '--bind-to', 'none', 'python3',
           root / 'performance17-control/rank_launcher.py', binaries[(source, scalar)],
           *dimensions, measured, warmup, int(resident)]
    cmd = list(map(str, cmd))
    (work / 'command.txt').write_text(shlex.join(cmd) + '\n')
    stop = threading.Event()
    samples = []
    monitor = threading.Thread(target=gpu_monitor, args=(work, stop, samples), daemon=True)
    monitor.start()
    print('START', name, flush=True)
    start = time.monotonic()
    try:
        with (work / 'stdout.log').open('wb') as stream:
            result = subprocess.run(cmd, cwd=work, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    finally:
        stop.set()
        monitor.join(timeout=10)
    elapsed = time.monotonic() - start
    if result.returncode:
        raise RuntimeError(name + ': ' + str(result.returncode))
    rows = list(csv.DictReader((work / 'samples.csv').open()))
    steady = [float(x['cal_loop3_seconds']) for x in rows if x['phase'] == 'steady']
    assert len(steady) == measured
    row = dict(name=name, source=source, scalar=scalar, resident=resident, dimensions=dimensions,
               threads=int(os.environ['OMP_NUM_THREADS']), process_seconds=elapsed,
               cold_seconds=float(rows[0]['cal_loop3_seconds']),
               warmup_seconds=[float(x['cal_loop3_seconds']) for x in rows if x['phase'] == 'warmup'],
               steady_seconds=steady, median_seconds=statistics.median(steady),
               min_seconds=min(steady), max_seconds=max(steady),
               max_linear_absolute=max(float(x['max_linear_absolute']) for x in rows),
               max_linear_scaled=max(float(x['max_linear_scaled']) for x in rows),
               peak_process_gpu_mib=max((x[3] for x in samples), default=None))
    (work / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
    print('END', name, row['median_seconds'], flush=True)
    return row

# Keep calibration separate. Workload selection uses only the baseline timing.
pilot = run_case('pilot-master-real-omp4', 'master', 'real', False, [16, 16, 64], measured=2, warmup=1)
dimensions = [20, 16, 64] if pilot['median_seconds'] < 0.08 else [12, 12, 48] if pilot['median_seconds'] > 2.0 else [16, 16, 64]
(out / 'calibration.json').write_text(json.dumps(dict(pilot=pilot, selected_dimensions=dimensions,
    rule='baseline median <0.08s: 20/16/64; >2s: 12/12/48; otherwise 16/16/64'), indent=2) + '\n')

variants = [('master', False), ('pr17', False), ('pr17', True), ('pr17-suggestions', False), ('pr17-suggestions', True)]
results = []
for threads in [1, 4]:
    setup(out / ('affinity-omp' + str(threads)), threads)
    for scalar in ['real', 'complex']:
        for round_index in range(3):
            order = variants[round_index:] + variants[:round_index]
            for source, resident in order:
                name = 'runs/omp{}-{}-round{}-{}-{}'.format(threads, scalar, round_index + 1, source, 'resident' if resident else 'default')
                row = run_case(name, source, scalar, resident, dimensions)
                row['round'] = round_index + 1
                results.append(row)
                (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')

def read_values(path, scalar):
    values = array.array('d')
    with path.open('rb') as stream:
        values.frombytes(stream.read())
    if scalar == 'complex':
        return [complex(values[i], values[i+1]) for i in range(0, len(values), 2)]
    return values

comparisons = []
for scalar in ['real', 'complex']:
    baseline = next(x for x in results if x['source'] == 'master' and x['threads'] == 1 and x['scalar'] == scalar)
    for which in ['first', 'last']:
        reference = read_values(out / baseline['name'] / (which + '-output.bin'), scalar)
        reference_index = (out / baseline['name'] / 'output-index.txt').read_bytes()
        for row in [x for x in results if x['scalar'] == scalar]:
            test = read_values(out / row['name'] / (which + '-output.bin'), scalar)
            assert (out / row['name'] / 'output-index.txt').read_bytes() == reference_index
            assert len(test) == len(reference)
            error = [abs(a-b) for a, b in zip(test, reference)]
            scaled = [e / (1 + abs(b)) for e, b in zip(error, reference)]
            assert all(math.isfinite(x) for x in error)
            record = dict(name=row['name'], output=which, baseline=baseline['name'], elements=len(test),
                          max_absolute=max(error), max_scaled=max(scaled), tolerance_scaled=1.e-10)
            comparisons.append(record)
            if record['max_scaled'] > 1.e-10:
                raise RuntimeError('Cross-variant disagreement: ' + str(record))
(out / 'comparisons.json').write_text(json.dumps(comparisons, indent=2) + '\n')
verify_sources()
print('ALL MICROBENCHMARKS PASSED', len(results), 'runs;', len(comparisons), 'full-output comparisons', flush=True)
