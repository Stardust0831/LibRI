| Threads | Type | Version | Residency | Steady median (s) | 3-run median range (s) | Paired speedup | Cold median (s) |
|---:|---|---|---|---:|---:|---:|---:|
| 4 | real | master | False | 0.643522 | 0.594641–0.646260 | 1.000× | 0.656476 |
| 4 | real | pr17 | False | 0.548421 | 0.524797–0.557175 | 1.160× | 0.592293 |
| 4 | real | pr17 | True | 0.231208 | 0.214989–0.247201 | 2.614× | 0.453233 |
| 4 | real | pr17-suggestions | False | 0.519355 | 0.514368–0.557080 | 1.155× | 0.573745 |
| 4 | real | pr17-suggestions | True | 0.203852 | 0.186864–0.215652 | 3.170× | 0.410772 |
| 4 | complex | master | False | 1.228868 | 1.194990–1.232335 | 1.000× | 1.150947 |
| 4 | complex | pr17 | False | 1.033810 | 1.022866–1.039819 | 1.182× | 1.024176 |
| 4 | complex | pr17 | True | 0.370325 | 0.367573–0.380196 | 3.318× | 0.680035 |
| 4 | complex | pr17-suggestions | False | 1.051796 | 1.018560–1.059525 | 1.172× | 1.084471 |
| 4 | complex | pr17-suggestions | True | 0.369800 | 0.362277–0.381046 | 3.323× | 0.622794 |
