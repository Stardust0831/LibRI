from pathlib import Path
import json
import re
import subprocess
from common import root, setup, verify_sources, binary_identity
import benchmark_common as bench

out = root / 'performance17-e2e-results'
setup(out)
source = root.parent / 'lcao-hse/pr8169-release-preparation-20261024/abacus-source'
binaries = {
    'master': root / 'performance17-abacus-master/abacus_std_gpu',
    'pr17': root / 'abacus-build/abacus_std_gpu',
    'fixed': root / 'suggestions17-abacus-build/abacus_std_gpu',
}
identities = {name: binary_identity(path) for name, path in binaries.items()}
(out / 'binaries.json').write_text(json.dumps(identities, indent=2) + '\n')
rows = []

def run(variant, material, repeat, warmup=False, complex_mode=False):
    tag = f'{material}-{variant}-r{repeat}' + ('-warmup' if warmup else '')
    work = out / tag
    atoms = bench.write_inputs(work, source, material, 'forces', 'gpu')
    if complex_mode:
        text = (work / 'INPUT').read_text()
        text = re.sub(r'(?m)^gamma_only .*$', 'gamma_only 0', text)
        text = re.sub(r'(?m)^exx_real_number .*$', 'exx_real_number 0', text)
        (work / 'INPUT').write_text(text)
    (work / 'gpu-before.csv').write_text(subprocess.check_output([
        'nvidia-smi', '--query-gpu=index,uuid,clocks.sm,clocks.mem,temperature.gpu,power.draw',
        '--format=csv'], text=True))
    print('START', tag, flush=True)
    result = bench.run_case(binaries[variant], work, atoms, 'forces', timeout=1200)
    result.update(variant=variant, material=material, repetition=repeat, warmup=warmup,
                  complex=complex_mode, directory=tag)
    (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    rows.append(result)
    (out / 'measurements.json').write_text(json.dumps(rows, indent=2) + '\n')
    info = (work / 'OUT.bench/INPUT.info').read_text()
    assert re.search(r'(?m)^\s*device_exx\s+gpu\s*$', info)
    print('PASS', tag, result['wall_seconds'], result['outer_steps'], flush=True)

# Warm each executable before the interleaved measured runs.
for variant in binaries:
    run(variant, 'si8', -1, warmup=True, complex_mode=True)
for material, complex_mode in [('si8', True), ('si64', False)]:
    names = list(binaries)
    for repeat in range(3):
        order = names[repeat:] + names[:repeat]
        for variant in order:
            run(variant, material, repeat, complex_mode=complex_mode)

comparisons = []
for row in rows:
    if row['warmup']:
        continue
    base = next(r for r in rows if not r['warmup'] and r['material'] == row['material']
                and r['variant'] == 'master' and r['repetition'] == row['repetition'])
    energy = abs(row['energy_ev'] - base['energy_ev'])
    assert len(row['force_ev_angstrom']) == len(base['force_ev_angstrom'])
    force = max(abs(a-b) for a,b in zip(row['force_ev_angstrom'], base['force_ev_angstrom']))
    comparisons.append(dict(case=row['directory'], energy_error_ev=energy,
                            max_force_error_ev_angstrom=force,
                            same_outer_steps=row['outer_steps'] == base['outer_steps'],
                            same_inner_steps=row['inner_steps'] == base['inner_steps'],
                            passed=energy <= 1e-6 and force <= 1e-4))
(out / 'comparisons.json').write_text(json.dumps(comparisons, indent=2) + '\n')
assert all(r['passed'] for r in comparisons)
verify_sources()
print('PERFORMANCE E2E PASSED', flush=True)
