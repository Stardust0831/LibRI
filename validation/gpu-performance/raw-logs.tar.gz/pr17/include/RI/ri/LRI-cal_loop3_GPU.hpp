// =================================
//  Author: Laiyuan Yang, Peize Lin
//  date: 2026.01.01
// =================================

#pragma once

#ifdef __GPU_RI

#include "LRI.h"
#include "LRI_Cal_Aux.h"
#include "../global/Array_Operator.h"
#include "../global/Map_Operator.h"
#include "../global/Tensor_Multiply.h"

#include "../global/gpu/GPU_Backend.h"
#include "gpu/GPU_LR_Batch_Plan.h"
#include "gpu/GPU_Resident_Blocks.h"
#include "gpu/GPU_Data_Input.h"
#include "gpu/GPU_Data_Mul.h"
#include "gpu/GPU_Data_Tmp.h"
#include "gpu/GPU_Data_Output.h"
#include "gpu/Dim.h"

#include <omp.h>
#include <typeinfo>

#ifdef __MKL_RI
#include <mkl_service.h>
#endif

namespace RI
{

template<typename TA, typename Tcell, std::size_t Ndim, typename Tdata>
void LRI<TA,Tcell,Ndim,Tdata>::cal_loop3_GPU(
	const std::vector<Label::ab_ab> &labels,
	std::map<TA, std::map<TAC, Tensor<Tdata>>> &Ds_result,
	const Tdata fac_add_Ds)
{
	using namespace Array_Operator;
	using Case_Plan = Gpu_LR_Case_Plan<TA, TAC, Tdata>;
	using Matrix_Map = typename Case_Plan::Matrix_Map;
	// Mutable atom filters can change the batch graph without changing tensors.
	// Keep the cache for the base, no-op filter only.
	const bool cacheable = typeid(*this->filter_atom) == typeid(Filter_Atom<TA, TAC>);
	if(cacheable)
	{
		if(!this->gpu_lr_plan_cache)
			this->gpu_lr_plan_cache.reset(new Gpu_LR_Plan_Cache<TA, TC, Tdata>());
		Gpu_LR_Plan_Cache<TA, TC, Tdata> &cache = *this->gpu_lr_plan_cache;
		const int thread_count = omp_get_max_threads();
		if(!cache.matches(this->period, thread_count, this->data_ab_name,
		                  this->parallel->list_A, this->data_pool))
			cache.capture(this->period, thread_count, this->data_ab_name,
			              this->parallel->list_A, this->data_pool);
	}

	struct Gpu_LR_Batch
	{
		const TA *Aa01 = nullptr;
		const TAC *Aa2 = nullptr;
		const TAC *Ab01 = nullptr;
		const TAC *Ab2 = nullptr;
		const Tensor<Tdata> *D_a = nullptr;
		const Tensor<Tdata> *D_b = nullptr;
		const Tensor<Tdata> *D_a0b0 = nullptr;
		const Tensor<Tdata> *D_response = nullptr;
		const GPU_Data::Pack *D_mul = nullptr;
	};
	constexpr std::size_t memory_limit = std::size_t(5)*1024*1024*1024;

	const Data_Pack_Wrapper<TA,TC,Tdata> data_wrapper(this->data_pool, this->data_ab_name);
	const LRI_Cal_Tools<TA,TC,Tdata> tools(this->period, this->data_pool, this->data_ab_name);

	std::map<TA, std::map<TAC, Tensor<Tdata>>> Ds_a_transpose, Ds_b_transpose;
	std::tie(Ds_a_transpose, Ds_b_transpose) = tools.cal_Ds_transpose(labels);

	#ifdef __MKL_RI
	const std::size_t mkl_threads = mkl_get_max_threads();
	mkl_set_num_threads(1);
	#endif

	using Resident = GPU_Data::Resident_Blocks<TA, TAC, Tdata>;
	using Resident_Map = typename Resident::Block_Map;
	std::unique_ptr<GPU_Backend::Context> call_context;
	Resident *resident = nullptr;
	if(this->gpu_resident_names.empty())
		call_context.reset(new GPU_Backend::Context(this->mpi_comm));
	else
	{
		if(!this->gpu_resident_blocks)
			this->gpu_resident_blocks.reset(new Resident(this->mpi_comm));
		resident = this->gpu_resident_blocks.get();
	}
	GPU_Backend::Queue &queue = resident ? resident->queue() : call_context->queue();
	const auto resident_for = [&](Label::ab input_label, int variant, const Matrix_Map &source) -> const Resident_Map*
	{
		if(!resident) return nullptr;
		const auto name = this->data_ab_name.find(input_label);
		if(name == this->data_ab_name.end() || !this->gpu_resident_names.count(name->second)) return nullptr;
		return resident->ensure(name->second, variant, source);
	};
	// The transposed C maps have a different element layout from the source C blocks.
	// In practice, data_wrapper(Label::ab::a) and data_wrapper(Label::ab::b) are both Cs_+suffix,
	// so the second call hits catche and return the address map built at the first call, no repeated upload.
	const Resident_Map *resident_a = resident_for(Label::ab::a, 0, data_wrapper(Label::ab::a).Ds_ab);
	const Resident_Map *resident_b = resident_for(Label::ab::b, 0, data_wrapper(Label::ab::b).Ds_ab);
	const Resident_Map *resident_v = resident_for(Label::ab::a0b0, 0, data_wrapper(Label::ab::a0b0).Ds_ab);
	const Resident_Map *resident_a_transpose = Ds_a_transpose.empty()
		? nullptr : resident_for(Label::ab::a, 1, Ds_a_transpose);
	const bool same_c_name = this->data_ab_name.at(Label::ab::a) == this->data_ab_name.at(Label::ab::b);
	const int b_transpose_variant = same_c_name ? 1 : 2;
	const Resident_Map *resident_b_transpose = Ds_b_transpose.empty()
		? nullptr : resident_for(Label::ab::b, b_transpose_variant, Ds_b_transpose);

	for(const Label::ab_ab &label : labels)
	{
		const std::vector<TA>  list_Aa01_Da = LRI_Cal_Aux::filter_list_map( this->parallel->list_A[Label_Tools::to_Aab_Aab(label)].a01, data_wrapper(Label::ab::a).Ds_ab );
		const std::vector<TAC> list_Ab01_Db = LRI_Cal_Aux::filter_list_map( this->parallel->list_A[Label_Tools::to_Aab_Aab(label)].b01, data_wrapper(Label::ab::b).Ds_ab );
		const std::vector<TAC> list_Aa2_Da  = LRI_Cal_Aux::filter_list_set( this->parallel->list_A[Label_Tools::to_Aab_Aab(label)].a2,  data_wrapper(Label::ab::a).index_Ds_ab[0] );
		const std::vector<TAC> list_Ab2_Db  = LRI_Cal_Aux::filter_list_set( this->parallel->list_A[Label_Tools::to_Aab_Aab(label)].b2,  data_wrapper(Label::ab::b).index_Ds_ab[0] );
		switch(label)
		{

			  // Aab_Aab::a01b01_a01b01

				case Label::ab_ab::a0b0_a1b1:
				{
					Case_Plan *case_plan = cacheable ? &this->gpu_lr_plan_cache->cases[label] : nullptr;
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b0).Ds_ab ),
						data_wrapper(Label::ab::a1b1).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b0).index_Ds_ab[0]),
						data_wrapper(Label::ab::a1b1).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b0, rDs_a1b1;
					rDs_b.defer_input_copies();
					rDs_a0b0.defer_input_copies();
					rDs_a1b1.defer_input_copies();
					rDs_b.bind_resident_blocks(resident_b);
					rDs_a0b0.bind_resident_blocks(resident_v);
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul = D_b * D_a0b0 * D_a1b1
					if(!case_plan || !case_plan->first.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_1(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b0 = tools.get_Ds_ab(Label::ab::a0b0, Aa01, Ab01);
								if(D_a0b0.empty())	continue;
								const Tensor<Tdata> &D_a1b1 = tools.get_Ds_ab(Label::ab::a1b1, Aa01, Ab01);
								if(D_a1b1.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for31(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Ab01 = &Ab01;
									batch.Ab2 = &Ab2;
									batch.D_b = &D_b;
									batch.D_a0b0 = &D_a0b0;
									batch.D_response = &D_a1b1;
									lri_batches_1[omp_get_thread_num()].push_back(batch);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_1)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Ab01 = *batch.Ab01;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_b = *batch.D_b;
							const Tensor<Tdata> &D_a0b0 = *batch.D_a0b0;
							const Tensor<Tdata> &D_a1b1 = *batch.D_response;
							rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
							rDs_a0b0.insert(Aa01, Ab01, D_a0b0);
							rDs_a1b1.insert(Aa01, Ab01, D_a1b1);
							const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_b.shape[1], D_b.shape[2], D_a0b0.shape[0]});
							const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab2, {D_tmp.shape[1], D_tmp.shape[2], D_a1b1.shape[0]});
							dim_0.input({D_b.shape[1], D_b.shape[2]}, D_a0b0.shape[0], D_b.shape[0]);
							dim_1.input({D_tmp.shape[1], D_tmp.shape[2]}, D_a1b1.shape[0], D_a1b1.shape[1]);
						}
						if(case_plan) case_plan->save_first({&rDs_b,&rDs_a0b0,&rDs_a1b1}, rDs_mul, &rDs_tmp, dim_0, &dim_1);
					}
					else
					{
						const Matrix_Map &source_0 = data_wrapper(Label::ab::b).Ds_ab;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a0b0).Ds_ab;
						const Matrix_Map &source_2 = data_wrapper(Label::ab::a1b1).Ds_ab;
						case_plan->load_first({&rDs_b,&rDs_a0b0,&rDs_a1b1},
						    {&source_0,&source_1,&source_2},
						    rDs_mul, &rDs_tmp, dim_0, &dim_1);
					}
					rDs_b.finish_deferred_copies();
					rDs_a0b0.finish_deferred_copies();
					rDs_a1b1.finish_deferred_copies();

					rDs_b.upload(queue);
					rDs_a0b0.upload(queue);
					rDs_a1b1.upload(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);
					dim_1.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a0b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b1.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						C0_left,
						rDs_mul.h_array_1.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a
					GPU_Data::Input<TA, TAC, Tdata> rDs_a;
					rDs_a.defer_input_copies();
					rDs_a.bind_resident_blocks(resident_a);
					if(!case_plan || !case_plan->second.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_2(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if (this->filter_atom->filter_for2(label, Aa01, Aa2))	continue;
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if (D_a.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2) // G
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab2))	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Aa2 = &Aa2;
									batch.Ab2 = &Ab2;
									batch.D_a = &D_a;
									batch.D_mul = &D_mul;
									lri_batches_2[omp_get_thread_num()].push_back(batch);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_2)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Aa2 = *batch.Aa2;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_a = *batch.D_a;
							const GPU_Data::Pack &D_mul = *batch.D_mul;
							rDs_mul.insert_2nd(D_mul);
							rDs_a.insert(Aa01, Aa2, D_a);
							rDs_output.insert( Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, {D_a.shape[2], D_mul.shape[0]});
							dim_2.input(D_a.shape[2], D_mul.shape[0], {D_a.shape[0], D_a.shape[1]});
						}
						if(case_plan) case_plan->save_second({&rDs_a}, rDs_mul, nullptr, rDs_output, dim_2, nullptr);
					}
					else
					{
						const Matrix_Map &source_0 = data_wrapper(Label::ab::a).Ds_ab;
						case_plan->load_second({&rDs_a},
						    {&source_0},
						    rDs_mul, nullptr, rDs_output, dim_2, nullptr);
					}
					rDs_a.finish_deferred_copies();

					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b0_a1b1

				case Label::ab_ab::a0b1_a1b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b1).Ds_ab ),
						data_wrapper(Label::ab::a1b0).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b1).index_Ds_ab[0]),
						data_wrapper(Label::ab::a1b0).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b1, rDs_a1b0;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul = D_b * D_a0b1 * D_a1b0
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b1 = tools.get_Ds_ab(Label::ab::a0b1, Aa01, Ab01);
								if(D_a0b1.empty())	continue;
								const Tensor<Tdata> &D_a1b0 = tools.get_Ds_ab(Label::ab::a1b0, Aa01, Ab01);
								if(D_a1b0.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for31(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b1.insert(Aa01, Ab01, D_a0b1);
										rDs_a1b0.insert(Aa01, Ab01, D_a1b0);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_b.shape[1], D_b.shape[2], D_a1b0.shape[0]});
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab2, {D_tmp.shape[1], D_tmp.shape[2], D_a0b1.shape[0]});
										dim_0.input({D_b.shape[1], D_b.shape[2]}, D_a1b0.shape[0], D_b.shape[0]);
										dim_1.input({D_tmp.shape[1], D_tmp.shape[2]}, D_a0b1.shape[0], D_a0b1.shape[1]);
									}
									rDs_b.insert_data(D_b);
									rDs_a0b1.insert_data(D_a0b1);
									rDs_a1b0.insert_data(D_a1b0);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b1.upload(queue);
					rDs_a1b0.upload(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);
					dim_1.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a1b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b1.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						C0_left,
						rDs_mul.h_array_1.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a
					GPU_Data::Input<TA, TAC, Tdata> rDs_a;
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if (this->filter_atom->filter_for2(label, Aa01, Aa2))	continue;
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if (D_a.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2) // G
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab2))	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_mul.insert_2nd(D_mul);
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_output.insert( Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, {D_a.shape[2], D_mul.shape[0]});
										dim_2.input(D_a.shape[2], D_mul.shape[0], {D_a.shape[0], D_a.shape[1]});
									}
									rDs_a.insert_data(D_a);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel

					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b1_a1b0

			  // Aab_Aab::a01b01_a01b2

				case Label::ab_ab::a0b0_a1b2:
				{
					Case_Plan *case_plan = cacheable ? &this->gpu_lr_plan_cache->cases[label] : nullptr;
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b0).Ds_ab ),
						data_wrapper(Label::ab::a1b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a1b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b2;
					rDs_b.defer_input_copies();
					rDs_a1b2.defer_input_copies();
					rDs_b.bind_resident_blocks(resident_b);
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b0b1a1 = b0b1b2 * a1b2
					// D_mul = D_b * D_a1b2
					if(!case_plan || !case_plan->first.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_3(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for (std::size_t ia01= 0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a1b2 = tools.get_Ds_ab(Label::ab::a1b2, Aa01, Ab2);
									if(D_a1b2.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Ab01 = &Ab01;
									batch.Ab2 = &Ab2;
									batch.D_b = &D_b;
									batch.D_response = &D_a1b2;
									lri_batches_3[omp_get_thread_num()].push_back(batch);
								} // end for Ab2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_3)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Ab01 = *batch.Ab01;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_b = *batch.D_b;
							const Tensor<Tdata> &D_a1b2 = *batch.D_response;
							rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
							rDs_a1b2.insert(Aa01, Ab2, D_a1b2);
							const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_b.shape[0], D_b.shape[1], D_a1b2.shape[0]});
							dim_0.input({D_b.shape[0], D_b.shape[1]}, D_a1b2.shape[0], D_b.shape[2]);
						}
						if(case_plan) case_plan->save_first({&rDs_b,&rDs_a1b2}, rDs_mul, nullptr, dim_0, nullptr);
					}
					else
					{
						const Matrix_Map &source_0 = data_wrapper(Label::ab::b).Ds_ab;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a1b2).Ds_ab;
						case_plan->load_first({&rDs_b,&rDs_a1b2},
						    {&source_0,&source_1},
						    rDs_mul, nullptr, dim_0, nullptr);
					}
					rDs_b.finish_deferred_copies();
					rDs_a1b2.finish_deferred_copies();

					rDs_b.upload(queue);
					rDs_a1b2.upload(queue);
					rDs_mul.upload_1st(queue);

					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a1b2.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a * D_a0b0
					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a0b0;
					rDs_a.defer_input_copies();
					rDs_a0b0.defer_input_copies();
					rDs_a.bind_resident_blocks(resident_a_transpose);
					rDs_a0b0.bind_resident_blocks(resident_v);

					if(!case_plan || !case_plan->second.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_4(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b0 = tools.get_Ds_ab(Label::ab::a0b0, Aa01, Ab01);
								if(D_a0b0.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
								{
									const TAC &Aa2 = list_Aa2[ia2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab01))	continue;
									const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
									if (D_a.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Aa2 = &Aa2;
									batch.Ab01 = &Ab01;
									batch.D_a = &D_a;
									batch.D_a0b0 = &D_a0b0;
									batch.D_mul = &D_mul;
									lri_batches_4[omp_get_thread_num()].push_back(batch);
								} // end for Ab01
							}  // end for Aa2
						} // end for Aa01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_4)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Aa2 = *batch.Aa2;
							const TAC &Ab01 = *batch.Ab01;
							const Tensor<Tdata> &D_a = *batch.D_a;
							const Tensor<Tdata> &D_a0b0 = *batch.D_a0b0;
							const GPU_Data::Pack &D_mul = *batch.D_mul;
							rDs_a.insert(Aa01, Aa2, D_a);
							rDs_a0b0.insert(Aa01, Ab01, D_a0b0);
							rDs_mul.insert_2nd(D_mul);
							const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_mul.shape[1], D_mul.shape[2], D_a0b0.shape[0]});
							rDs_output.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, {D_a.shape[2], D_tmp.shape[0]});
							dim_1.input({D_mul.shape[1], D_mul.shape[2]}, D_a0b0.shape[0], D_a0b0.shape[1]);
							dim_2.input(D_a.shape[2], D_tmp.shape[0], {D_a.shape[0], D_a.shape[1]});
						}
						if(case_plan) case_plan->save_second({&rDs_a,&rDs_a0b0}, rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					else
					{
						const Matrix_Map &source_0 = Ds_a_transpose;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a0b0).Ds_ab;
						case_plan->load_second({&rDs_a,&rDs_a0b0},
						    {&source_0,&source_1},
						    rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					rDs_a.finish_deferred_copies();
					rDs_a0b0.finish_deferred_copies();

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					rDs_a0b0.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = false;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_2, rDs_a0b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b0_a1b2

				case Label::ab_ab::a0b1_a1b2:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b1).Ds_ab ),
						data_wrapper(Label::ab::a1b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a1b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// a1b0b1 = a1b2 * b0b1b2
					// D_mul = D_b * D_a1b2
					#pragma omp parallel
					{
						for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for (std::size_t ia01= 0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a1b2 = tools.get_Ds_ab(Label::ab::a1b2, Aa01, Ab2);
									if(D_a1b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b2.insert(Aa01, Ab2, D_a1b2);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a1b2.shape[0], D_b.shape[0], D_b.shape[1]});
										dim_0.input(D_a1b2.shape[0], {D_b.shape[0], D_b.shape[1]}, D_a1b2.shape[1]);
									}
									rDs_b.insert_data(D_b);
									rDs_a1b2.insert_data(D_a1b2);
								} // end for Ab2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a1b2.upload(queue);
					rDs_mul.upload_1st(queue);

					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b2.d_array, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a * D_a0b1
					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a0b1;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b1 = tools.get_Ds_ab(Label::ab::a0b1, Aa01, Ab01);
								if(D_a0b1.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
								{
									const TAC &Aa2 = list_Aa2[ia2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab01))	continue;
									const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
									if (D_a.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a0b1.insert(Aa01, Ab01, D_a0b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a0b1.shape[0], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, {D_a.shape[2], D_tmp.shape[2]});
										dim_1.input(D_a0b1.shape[0], {D_mul.shape[0], D_mul.shape[1]}, D_a0b1.shape[1]);
										dim_2.input(D_a.shape[2], D_tmp.shape[2], {D_a.shape[0], D_a.shape[1]});
									}
									rDs_a.insert_data(D_a);
									rDs_a0b1.insert_data(D_a0b1);
								} // end for Ab01
							}  // end for Aa2
						} // end for Aa01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					rDs_a0b1.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = false;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b1.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b1_a1b2

				case Label::ab_ab::a0b2_a1b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b0).Ds_ab ),
						data_wrapper(Label::ab::a0b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a0b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b0b1a0 = b0b1b2 * a0b2
					// D_mul = D_b * D_a0b2
					#pragma omp parallel
					{
						for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for (std::size_t ia01= 0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a0b2 = tools.get_Ds_ab(Label::ab::a0b2, Aa01, Ab2);
									if(D_a0b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b2.insert(Aa01, Ab2, D_a0b2);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_b.shape[0], D_b.shape[1], D_a0b2.shape[0]});
										dim_0.input({D_b.shape[0], D_b.shape[1]}, D_a0b2.shape[0], D_b.shape[2]);
									}
									rDs_b.insert_data(D_b);
									rDs_a0b2.insert_data(D_a0b2);
								} // end for Ab2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b2.upload(queue);
					rDs_mul.upload_1st(queue);

					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a0b2.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a * D_a1b0
					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a1b0;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b0 = tools.get_Ds_ab(Label::ab::a1b0, Aa01, Ab01);
								if(D_a1b0.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
								{
									const TAC &Aa2 = list_Aa2[ia2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab01))	continue;
									const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
									if (D_a.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a1b0.insert(Aa01, Ab01, D_a1b0);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_mul.shape[1], D_mul.shape[2], D_a1b0.shape[0]});
										rDs_output.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, {D_a.shape[2], D_tmp.shape[0]});
										dim_1.input({D_mul.shape[1], D_mul.shape[2]}, D_a1b0.shape[0], D_a1b0.shape[1]);
										dim_2.input(D_a.shape[2], D_tmp.shape[0], {D_a.shape[0], D_a.shape[1]});
									}
									rDs_a.insert_data(D_a);
									rDs_a1b0.insert_data(D_a1b0);
								} // end for Ab01
							}  // end for Aa2
						} // end for Aa01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					rDs_a1b0.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = false;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_2, rDs_a1b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b2_a1b0

				case Label::ab_ab::a0b2_a1b1:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map( LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b1).Ds_ab ),
						data_wrapper(Label::ab::a0b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 =
						list_Aa2_Da;
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a0b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// a0b0b1 = a0b2 * b0b1b2
					// D_mul = D_b * D_a0b2
					#pragma omp parallel
					{
						for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for (std::size_t ia01= 0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a0b2 = tools.get_Ds_ab(Label::ab::a0b2, Aa01, Ab2);
									if(D_a0b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b2.insert(Aa01, Ab2, D_a0b2);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a0b2.shape[0], D_b.shape[0], D_b.shape[1]});
										dim_0.input(D_a0b2.shape[0], {D_b.shape[0], D_b.shape[1]}, D_a0b2.shape[1]);
									}
									rDs_b.insert_data(D_b);
									rDs_a0b2.insert_data(D_a0b2);
								} // end for Ab2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b2.upload(queue);
					rDs_mul.upload_1st(queue);

					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b2.d_array, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a * D_a1b1
					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a1b1;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b1 = tools.get_Ds_ab(Label::ab::a1b1, Aa01, Ab01);
								if(D_a1b1.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2) // F
								{
									const TAC &Aa2 = list_Aa2[ia2];
									if (this->filter_atom->filter_for32(label, Aa01, Aa2, Ab01))	continue;
									const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
									if (D_a.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a1b1.insert(Aa01, Ab01, D_a1b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a1b1.shape[0], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, {D_a.shape[2], D_tmp.shape[2]});
										dim_1.input(D_a1b1.shape[0], {D_mul.shape[0], D_mul.shape[1]}, D_a1b1.shape[1]);
										dim_2.input(D_a.shape[2], D_tmp.shape[2], {D_a.shape[0], D_a.shape[1]});
									}
									rDs_a.insert_data(D_a);
									rDs_a1b1.insert_data(D_a1b1);
								} // end for Ab01
							}  // end for Aa2
						} // end for Aa01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_a.upload(queue);
					rDs_a1b1.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = false;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b1.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b2_a1b1

			  // Aab_Aab::a01b01_a2b01

				case Label::ab_ab::a0b0_a2b1:
				{
					Case_Plan *case_plan = cacheable ? &this->gpu_lr_plan_cache->cases[label] : nullptr;
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b0).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b1).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b0).index_Ds_ab[0]),
						data_wrapper(Label::ab::a2b1).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b1;
					rDs_a.defer_input_copies();
					rDs_a2b1.defer_input_copies();
					rDs_a.bind_resident_blocks(resident_a_transpose);
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b1a1a0 = a2b1 * a1a0a2
					// D_mul = D_a * D_a2b1
					if(!case_plan || !case_plan->first.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_5(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for (std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Aa2))	continue;
									const Tensor<Tdata> &D_a2b1 = tools.get_Ds_ab(Label::ab::a2b1, Aa2, Ab01);
									if(D_a2b1.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Aa2 = &Aa2;
									batch.Ab01 = &Ab01;
									batch.D_a = &D_a;
									batch.D_response = &D_a2b1;
									lri_batches_5[omp_get_thread_num()].push_back(batch);

								} // end for Aa2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_5)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Aa2 = *batch.Aa2;
							const TAC &Ab01 = *batch.Ab01;
							const Tensor<Tdata> &D_a = *batch.D_a;
							const Tensor<Tdata> &D_a2b1 = *batch.D_response;
							rDs_a.insert(Aa01, Aa2, D_a);
							rDs_a2b1.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % this->period}, D_a2b1);
							const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a2b1.shape[1], D_a.shape[0], D_a.shape[1]});
							dim_0.input(D_a2b1.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b1.shape[0]);
						}
						if(case_plan) case_plan->save_first({&rDs_a,&rDs_a2b1}, rDs_mul, nullptr, dim_0, nullptr);
					}
					else
					{
						const Matrix_Map &source_0 = Ds_a_transpose;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a2b1).Ds_ab;
						case_plan->load_first({&rDs_a,&rDs_a2b1},
						    {&source_0,&source_1},
						    rDs_mul, nullptr, dim_0, nullptr);
					}
					rDs_a.finish_deferred_copies();
					rDs_a2b1.finish_deferred_copies();

					rDs_a.upload(queue);
					rDs_a2b1.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b1.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a0b0 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b0;
					rDs_b.defer_input_copies();
					rDs_a0b0.defer_input_copies();
					rDs_b.bind_resident_blocks(resident_b);
					rDs_a0b0.bind_resident_blocks(resident_v);

					if(!case_plan || !case_plan->second.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_6(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b0 = tools.get_Ds_ab(Label::ab::a0b0, Aa01, Ab01);
								if(D_a0b0.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Ab01 = &Ab01;
									batch.Ab2 = &Ab2;
									batch.D_b = &D_b;
									batch.D_a0b0 = &D_a0b0;
									batch.D_mul = &D_mul;
									lri_batches_6[omp_get_thread_num()].push_back(batch);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_6)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Ab01 = *batch.Ab01;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_b = *batch.D_b;
							const Tensor<Tdata> &D_a0b0 = *batch.D_a0b0;
							const GPU_Data::Pack &D_mul = *batch.D_mul;
							rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
							rDs_a0b0.insert(Aa01, Ab01, D_a0b0);
							rDs_mul.insert_2nd(D_mul);
							const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a0b0.shape[1], D_mul.shape[0], D_mul.shape[1]});
							rDs_output.insert(Aa01, Ab2, {D_tmp.shape[2], D_b.shape[2]});
							dim_1.input(D_a0b0.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a0b0.shape[0]);
							dim_2.input(D_tmp.shape[2], D_b.shape[2], {D_b.shape[0], D_b.shape[1]});
						}
						if(case_plan) case_plan->save_second({&rDs_b,&rDs_a0b0}, rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					else
					{
						const Matrix_Map &source_0 = data_wrapper(Label::ab::b).Ds_ab;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a0b0).Ds_ab;
						case_plan->load_second({&rDs_b,&rDs_a0b0},
						    {&source_0,&source_1},
						    rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					rDs_b.finish_deferred_copies();
					rDs_a0b0.finish_deferred_copies();

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_b.upload(queue);
					rDs_a0b0.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b0.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b0_a2b1

				case Label::ab_ab::a0b1_a2b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b1).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b0).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b1).index_Ds_ab[0]),
						data_wrapper(Label::ab::a2b0).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b0;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// a0a1b0 = a0a1a2 * a2b0
					// D_mul = D_a * D_a2b0
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for (std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Aa2))	continue;
									const Tensor<Tdata> &D_a2b0 = tools.get_Ds_ab(Label::ab::a2b0, Aa2, Ab01);
									if(D_a2b0.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b0.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % this->period}, D_a2b0);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a.shape[0], D_a.shape[1], D_a2b0.shape[1]});
										dim_0.input({D_a.shape[0], D_a.shape[1]}, D_a2b0.shape[1], D_a.shape[2]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b0.insert_data(D_a2b0);

								} // end for Aa2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b0.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_a2b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a0b1 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b1;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b1 = tools.get_Ds_ab(Label::ab::a0b1, Aa01, Ab01);
								if(D_a0b1.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b1.insert(Aa01, Ab01, D_a0b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_mul.shape[1], D_mul.shape[2], D_a0b1.shape[1]});
										rDs_output.insert(Aa01, Ab2, {D_tmp.shape[0], D_b.shape[2]});
										dim_1.input({D_mul.shape[1], D_mul.shape[2]}, D_a0b1.shape[1], D_a0b1.shape[0]);
										dim_2.input(D_tmp.shape[0], D_b.shape[2], {D_b.shape[0], D_b.shape[1]});
									}
									rDs_b.insert_data(D_b);
									rDs_a0b1.insert_data(D_a0b1);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_b.upload(queue);
					rDs_a0b1.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_2, rDs_a0b1.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b1_a2b0

				case Label::ab_ab::a1b0_a2b1:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b0).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b1).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b0).index_Ds_ab[0]),
						data_wrapper(Label::ab::a2b1).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b1;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b1a0a1 = a2b1 * a0a1a2
					// D_mul = D_a * D_a2b1
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for (std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Aa2))	continue;
									const Tensor<Tdata> &D_a2b1 = tools.get_Ds_ab(Label::ab::a2b1, Aa2, Ab01);
									if(D_a2b1.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b1.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % this->period}, D_a2b1);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a2b1.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_0.input(D_a2b1.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b1.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b1.insert_data(D_a2b1);

								} // end for Aa2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b1.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b1.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a1b0 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b0;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b0 = tools.get_Ds_ab(Label::ab::a1b0, Aa01, Ab01);
								if(D_a1b0.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b0.insert(Aa01, Ab01, D_a1b0);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a1b0.shape[1], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa01, Ab2, {D_tmp.shape[2], D_b.shape[2]});
										dim_1.input(D_a1b0.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a1b0.shape[0]);
										dim_2.input(D_tmp.shape[2], D_b.shape[2], {D_b.shape[0], D_b.shape[1]});
									}
									rDs_b.insert_data(D_b);
									rDs_a1b0.insert_data(D_a1b0);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_b.upload(queue);
					rDs_a1b0.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b0.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b0_a2b1

				case Label::ab_ab::a1b1_a2b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b1).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b0).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set( LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b1).index_Ds_ab[0]),
						data_wrapper(Label::ab::a2b0).index_Ds_ab[0]);
					const std::vector<TAC> &list_Ab2 =
						list_Ab2_Db;

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b0;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// a1a0b0 = a1a0a2 * a2b0
					// D_mul = D_a * D_a2b0
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for (std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Aa2))	continue;
									const Tensor<Tdata> &D_a2b0 = tools.get_Ds_ab(Label::ab::a2b0, Aa2, Ab01);
									if(D_a2b0.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b0.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % this->period}, D_a2b0);
										const GPU_Data::Pack &D_mul = rDs_mul.insert_1st(Aa01, Ab01, {D_a.shape[0], D_a.shape[1], D_a2b0.shape[1]});
										dim_0.input({D_a.shape[0], D_a.shape[1]}, D_a2b0.shape[1], D_a.shape[2]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b0.insert_data(D_a2b0);

								} // end for Aa2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b0.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_a2b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a1b1 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b1;

					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01) // A
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01) // G
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b1 = tools.get_Ds_ab(Label::ab::a1b1, Aa01, Ab01);
								if(D_a1b1.empty())	continue;
								const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab01);
								if (!D_mul.exist)	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab01, Ab2))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b1.insert(Aa01, Ab01, D_a1b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_mul.shape[1], D_mul.shape[2], D_a1b1.shape[1]});
										rDs_output.insert(Aa01, Ab2, {D_tmp.shape[0], D_b.shape[2]});
										dim_1.input({D_mul.shape[1], D_mul.shape[2]}, D_a1b1.shape[1], D_a1b1.shape[0]);
										dim_2.input(D_tmp.shape[0], D_b.shape[2], {D_b.shape[0], D_b.shape[1]});
									}
									rDs_b.insert_data(D_b);
									rDs_a1b1.insert_data(D_a1b1);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);
					rDs_mul.upload_2nd(queue);
					rDs_b.upload(queue);
					rDs_a1b1.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::NoTrans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_2, rDs_a1b1.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b1_a2b0

			  // Aab_Aab::a01b01_a2b2

				case Label::ab_ab::a0b0_a2b2:
				{
					Case_Plan *case_plan = cacheable ? &this->gpu_lr_plan_cache->cases[label] : nullptr;
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b0).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b2).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a2b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b2;
					rDs_a.defer_input_copies();
					rDs_a2b2.defer_input_copies();
					rDs_a.bind_resident_blocks(resident_a_transpose);
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b2a1a0 = a2b2 * a1a0a2
					// D_mul = D_a * D_a2b2
					if(!case_plan || !case_plan->first.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_7(omp_get_max_threads());
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if(this->filter_atom->filter_for31(label,Aa01,Aa2,Ab2))	continue;
									const Tensor<Tdata> &D_a2b2 = tools.get_Ds_ab(Label::ab::a2b2, Aa2, Ab2);
									if(D_a2b2.empty())	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Aa2 = &Aa2;
									batch.Ab2 = &Ab2;
									batch.D_a = &D_a;
									batch.D_response = &D_a2b2;
									lri_batches_7[omp_get_thread_num()].push_back(batch);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_7)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Aa2 = *batch.Aa2;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_a = *batch.D_a;
							const Tensor<Tdata> &D_a2b2 = *batch.D_response;
							rDs_a.insert(Aa01, Aa2, D_a);
							rDs_a2b2.insert(Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, D_a2b2);
							rDs_mul.insert_1st(Aa01, Ab2, {D_a2b2.shape[1], D_a.shape[0], D_a.shape[1]});
							dim_0.input(D_a2b2.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b2.shape[0]);
						}
						if(case_plan) case_plan->save_first({&rDs_a,&rDs_a2b2}, rDs_mul, nullptr, dim_0, nullptr);
					}
					else
					{
						const Matrix_Map &source_0 = Ds_a_transpose;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a2b2).Ds_ab;
						case_plan->load_first({&rDs_a,&rDs_a2b2},
						    {&source_0,&source_1},
						    rDs_mul, nullptr, dim_0, nullptr);
					}
					rDs_a.finish_deferred_copies();
					rDs_a2b2.finish_deferred_copies();

					rDs_a.upload(queue);
					rDs_a2b2.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b2.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a0b0 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b0;
					rDs_b.defer_input_copies();
					rDs_a0b0.defer_input_copies();
					rDs_b.bind_resident_blocks(resident_b_transpose);
					rDs_a0b0.bind_resident_blocks(resident_v);

					if(!case_plan || !case_plan->second.ready)
					{
					std::vector<std::vector<Gpu_LR_Batch>> lri_batches_8(omp_get_max_threads());
					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b0 = tools.get_Ds_ab(Label::ab::a0b0, Aa01, Ab01);
								if(D_a0b0.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									// The output block is (Aa01, Ab01); Ab2 is only an intermediate atom.
									if (this->filter_atom->filter_for32(label, Aa01, Ab2, Ab01))	continue;
									const Tensor<Tdata> &D_b = Global_Func::find(Ds_b_transpose, Ab01.first, TAC{Ab2.first, (Ab2.second-Ab01.second)%this->period});
									if(D_b.empty())	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									Gpu_LR_Batch batch;
									batch.Aa01 = &Aa01;
									batch.Ab01 = &Ab01;
									batch.Ab2 = &Ab2;
									batch.D_b = &D_b;
									batch.D_a0b0 = &D_a0b0;
									batch.D_mul = &D_mul;
									lri_batches_8[omp_get_thread_num()].push_back(batch);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel
					// Register the collected GEMM batches in one order; workers no longer contend on shared maps.
					for(const auto &thread_batches : lri_batches_8)
						for(const Gpu_LR_Batch &batch : thread_batches)
						{
							const TA &Aa01 = *batch.Aa01;
							const TAC &Ab01 = *batch.Ab01;
							const TAC &Ab2 = *batch.Ab2;
							const Tensor<Tdata> &D_b = *batch.D_b;
							const Tensor<Tdata> &D_a0b0 = *batch.D_a0b0;
							const GPU_Data::Pack &D_mul = *batch.D_mul;
							rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
							rDs_a0b0.insert(Aa01, Ab01, D_a0b0);
							rDs_mul.insert_2nd(D_mul);
							const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a0b0.shape[1], D_mul.shape[0], D_mul.shape[1]});
							rDs_output.insert(Aa01, Ab01, {D_tmp.shape[2], D_b.shape[0]});
							dim_1.input(D_a0b0.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a0b0.shape[0]);
							dim_2.input(D_tmp.shape[2], D_b.shape[0], {D_b.shape[1], D_b.shape[2]});
						}
						if(case_plan) case_plan->save_second({&rDs_b,&rDs_a0b0}, rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					else
					{
						const Matrix_Map &source_0 = Ds_b_transpose;
						const Matrix_Map &source_1 = data_wrapper(Label::ab::a0b0).Ds_ab;
						case_plan->load_second({&rDs_b,&rDs_a0b0},
						    {&source_0,&source_1},
						    rDs_mul, &rDs_tmp, rDs_output, dim_1, &dim_2);
					}
					rDs_b.finish_deferred_copies();
					rDs_a0b0.finish_deferred_copies();

					rDs_b.upload(queue);
					rDs_a0b0.upload(queue);
					rDs_mul.upload_2nd(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b0.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b0_a2b2

				case Label::ab_ab::a0b1_a2b2:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b1).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b2).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a0b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a2b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b2a1a0 = a2b2 * a1a0a2
					// D_mul = D_a * D_a2b2
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if(this->filter_atom->filter_for31(label,Aa01,Aa2,Ab2))	continue;
									const Tensor<Tdata> &D_a2b2 = tools.get_Ds_ab(Label::ab::a2b2, Aa2, Ab2);
									if(D_a2b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b2.insert(Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, D_a2b2);
										rDs_mul.insert_1st(Aa01, Ab2, {D_a2b2.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_0.input(D_a2b2.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b2.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b2.insert_data(D_a2b2);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b2.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b2.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a0b1 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a0b1;

					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a0b1 = tools.get_Ds_ab(Label::ab::a0b1, Aa01, Ab01);
								if(D_a0b1.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab2, Ab01))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b1.insert(Aa01, Ab01, D_a0b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a0b1.shape[1], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa01, Ab01, {D_tmp.shape[2], D_b.shape[0]});
										dim_1.input(D_a0b1.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a0b1.shape[0]);
										dim_2.input(D_tmp.shape[2], D_b.shape[0], {D_b.shape[1], D_b.shape[2]});
									}
									rDs_b.insert_data(D_b);
									rDs_a0b1.insert_data(D_a0b1);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b1.upload(queue);
					rDs_mul.upload_2nd(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b1.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b1_a2b2

				case Label::ab_ab::a1b0_a2b2:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b0).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b2).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a2b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b2a0a1 = a2b2 * a0a1a2
					// D_mul = D_a * D_a2b2
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if(this->filter_atom->filter_for31(label,Aa01,Aa2,Ab2))	continue;
									const Tensor<Tdata> &D_a2b2 = tools.get_Ds_ab(Label::ab::a2b2, Aa2, Ab2);
									if(D_a2b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b2.insert(Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, D_a2b2);
										rDs_mul.insert_1st(Aa01, Ab2, {D_a2b2.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_0.input(D_a2b2.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b2.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b2.insert_data(D_a2b2);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b2.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b2.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a1b0 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b0;

					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b0 = tools.get_Ds_ab(Label::ab::a1b0, Aa01, Ab01);
								if(D_a1b0.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab2, Ab01))	continue;
									const Tensor<Tdata> &D_b = Global_Func::find(Ds_b_transpose, Ab01.first, TAC{Ab2.first, (Ab2.second-Ab01.second)%this->period});
									if(D_b.empty())	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b0.insert(Aa01, Ab01, D_a1b0);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a1b0.shape[1], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa01, Ab01, {D_tmp.shape[2], D_b.shape[0]});
										dim_1.input(D_a1b0.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a1b0.shape[0]);
										dim_2.input(D_tmp.shape[2], D_b.shape[0], {D_b.shape[1], D_b.shape[2]});
									}
									rDs_b.insert_data(D_b);
									rDs_a1b0.insert_data(D_a1b0);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a1b0.upload(queue);
					rDs_mul.upload_2nd(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b0.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b0_a2b2

				case Label::ab_ab::a1b1_a2b2:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b1).Ds_ab );
					const std::vector<TAC>  list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b2).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a1b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a2b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_a2b2;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul;
					GPU_Data::Tmp<TA, TAC, Tdata> rDs_tmp;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// b2a0a1 = a2b2 * a0a1a2
					// D_mul = D_a * D_a2b2
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ia2 = 0; ia2 < list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								if(this->filter_atom->filter_for2(label,Aa01,Aa2))	continue;
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if(this->filter_atom->filter_for31(label,Aa01,Aa2,Ab2))	continue;
									const Tensor<Tdata> &D_a2b2 = tools.get_Ds_ab(Label::ab::a2b2, Aa2, Ab2);
									if(D_a2b2.empty())	continue;

									#pragma omp critical(rDs_mul)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b2.insert(Aa2.first, {Ab2.first, (Ab2.second - Aa2.second) % period}, D_a2b2);
										rDs_mul.insert_1st(Aa01, Ab2, {D_a2b2.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_0.input(D_a2b2.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b2.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b2.insert_data(D_a2b2);
								} // end for Ab2
							} // end for Aa2
						} // end for Aa01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b2.upload(queue);
					rDs_mul.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b2.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul.d_array_1,
						rDs_mul.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul * D_a1b1 * D_b
					GPU_Data::Input<TA, TAC, Tdata> rDs_b, rDs_a1b1;

					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const Tensor<Tdata> &D_a1b1 = tools.get_Ds_ab(Label::ab::a1b1, Aa01, Ab01);
								if(D_a1b1.empty())	continue;
								for (std::size_t ib2 = 0; ib2 < list_Ab2.size(); ++ib2)
								{
									const TAC &Ab2 = list_Ab2[ib2];
									if (this->filter_atom->filter_for32(label, Aa01, Ab2, Ab01))	continue;
									const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
									if(D_b.empty())	continue;
									const GPU_Data::Pack &D_mul = rDs_mul.find_2nd(Aa01, Ab2);
									if (!D_mul.exist)	continue;

									#pragma omp critical(rDs_output)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b1.insert(Aa01, Ab01, D_a1b1);
										rDs_mul.insert_2nd(D_mul);
										const GPU_Data::Pack &D_tmp = rDs_tmp.insert({D_a1b1.shape[1], D_mul.shape[0], D_mul.shape[1]});
										rDs_output.insert(Aa01, Ab01, {D_tmp.shape[2], D_b.shape[0]});
										dim_1.input(D_a1b1.shape[1], {D_mul.shape[0], D_mul.shape[1]}, D_a1b1.shape[0]);
										dim_2.input(D_tmp.shape[2], D_b.shape[0], {D_b.shape[1], D_b.shape[2]});
									}
									rDs_b.insert_data(D_b);
									rDs_a1b1.insert_data(D_a1b1);
								} // end for Aa01
							} // end for Ab2
						} // end for Ab01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a1b1.upload(queue);
					rDs_mul.upload_2nd(queue);
					const std::vector<GPU_Backend::Int> rDs_tmp_segments_size = rDs_tmp.upload(memory_limit, queue);
					rDs_output.upload(queue);

					dim_1.upload(queue);
					dim_2.upload(queue);

					constexpr bool C0_left = true;
					GPU_Backend::gemmVbatched2s(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b1.d_array, rDs_mul.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{0}, rDs_tmp.d_array,
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						C0_left,
						rDs_output.h_array.size(), rDs_tmp_segments_size, queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b1_a2b2

			  // Aab_Aab::a01b2_a2b01

				case Label::ab_ab::a1b2_a2b1:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b1).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a2b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a1b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_b, rDs_a1b2, rDs_a2b1;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul_1, rDs_mul_2;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul1 = D_b * D_a1b2
					// b0b1a1 = b0b1b2 * a1b2
					#pragma omp parallel
					{
						for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a1b2 = tools.get_Ds_ab(Label::ab::a1b2, Aa01, Ab2);
									if(D_a1b2.empty())	continue;

									#pragma omp critical(rDs_mul_1)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b2.insert(Aa01, Ab2, D_a1b2);
										rDs_mul_1.insert_1st(Aa01, Ab01, {D_b.shape[0], D_b.shape[1], D_a1b2.shape[0]});
										dim_0.input({D_b.shape[0], D_b.shape[1]}, D_a1b2.shape[0], D_b.shape[2]);
									}
									rDs_b.insert_data(D_b);
									rDs_a1b2.insert_data(D_a1b2);
								} // end for Ab2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a1b2.upload(queue);
					rDs_mul_1.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a1b2.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_1.d_array_1,
						rDs_mul_1.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_mul2 = D_a2b1 * D_a
					// b1a1a0 = a2b1 * a1a0a2
					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									// Screen the output pair; Aa2 is summed over, not an output atom.
									if(this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
									if(this->filter_atom->filter_for32(label, Aa01, Ab01, Aa2))	continue;
									const Tensor<Tdata> &D_a2b1 = tools.get_Ds_ab(Label::ab::a2b1, Aa2, Ab01);
									if(D_a2b1.empty())	continue;

									#pragma omp critical(rDs_mul_2)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b1.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, D_a2b1);
										rDs_mul_2.insert_1st(Aa01, Ab01, {D_a2b1.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_1.input(D_a2b1.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b1.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b1.insert_data(D_a2b1);
								} // end for Aa2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b1.upload(queue);
					rDs_mul_2.upload_1st(queue);
					dim_1.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b1.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_1,
						rDs_mul_2.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul2 * D_mul1
					// a0b0 = b1a1a0 * b0b1a1
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const GPU_Data::Pack &D_mul_1 = rDs_mul_1.find_2nd(Aa01, Ab01);
								if (!D_mul_1.exist)	continue;
								const GPU_Data::Pack &D_mul_2 = rDs_mul_2.find_2nd(Aa01, Ab01);
								if (!D_mul_2.exist)	continue;

								#pragma omp critical(rDs_output)
								{
									rDs_mul_1.insert_2nd(D_mul_1);
									rDs_mul_2.insert_2nd(D_mul_2);
									rDs_output.insert(Aa01, Ab01, {D_mul_2.shape[2], D_mul_1.shape[0]});
									dim_2.input(D_mul_2.shape[2], D_mul_1.shape[0], {D_mul_1.shape[1], D_mul_1.shape[2]});
								}
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_mul_1.upload_2nd(queue);
					rDs_mul_2.upload_2nd(queue);
					rDs_output.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_2, rDs_mul_1.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b2_a2b1

				case Label::ab_ab::a0b2_a2b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b0).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a2b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a0b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_b, rDs_a0b2, rDs_a2b0;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul_1, rDs_mul_2;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul1 = D_b * D_a0b2
					// a0b0b1 = a0b2 * b0b1b2
					#pragma omp parallel
					{
						for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a0b2 = tools.get_Ds_ab(Label::ab::a0b2, Aa01, Ab2);
									if(D_a0b2.empty())	continue;

									#pragma omp critical(rDs_mul_1)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b2.insert(Aa01, Ab2, D_a0b2);
										rDs_mul_1.insert_1st(Aa01, Ab01, {D_a0b2.shape[0], D_b.shape[0], D_b.shape[1]});
										dim_0.input(D_a0b2.shape[0], {D_b.shape[0], D_b.shape[1]}, D_a0b2.shape[1]);
									}
									rDs_b.insert_data(D_b);
									rDs_a0b2.insert_data(D_a0b2);
								} // end for Ab2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b2.upload(queue);
					rDs_mul_1.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a0b2.d_array, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_1.d_array_1,
						rDs_mul_1.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_mul2 = D_a2b0 * D_a
					// a1a0b0 = a1a0a2 * a2b0
					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								const Tensor<Tdata> &D_a = Global_Func::find(Ds_a_transpose, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									// Screen the output pair; Aa2 is summed over, not an output atom.
									if(this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
									if(this->filter_atom->filter_for32(label, Aa01, Ab01, Aa2))	continue;
									const Tensor<Tdata> &D_a2b0 = tools.get_Ds_ab(Label::ab::a2b0, Aa2, Ab01);
									if(D_a2b0.empty())	continue;

									#pragma omp critical(rDs_mul_2)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b0.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, D_a2b0);
										rDs_mul_2.insert_1st(Aa01, Ab01, {D_a.shape[0], D_a.shape[1], D_a2b0.shape[1]});
										dim_1.input({D_a.shape[0], D_a.shape[1]}, D_a2b0.shape[1], D_a.shape[2]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b0.insert_data(D_a2b0);
								} // end for Aa2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b0.upload(queue);
					rDs_mul_2.upload_1st(queue);
					dim_1.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_a2b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_1,
						rDs_mul_2.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul2 * D_mul1
					// a1b1 = a1a0b0 * a0b0b1
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const GPU_Data::Pack &D_mul_1 = rDs_mul_1.find_2nd(Aa01, Ab01);
								if (!D_mul_1.exist)	continue;
								const GPU_Data::Pack &D_mul_2 = rDs_mul_2.find_2nd(Aa01, Ab01);
								if (!D_mul_2.exist)	continue;

								#pragma omp critical(rDs_output)
								{
									rDs_mul_1.insert_2nd(D_mul_1);
									rDs_mul_2.insert_2nd(D_mul_2);
									rDs_output.insert(Aa01, Ab01, {D_mul_2.shape[0], D_mul_1.shape[2]});
									dim_2.input(D_mul_2.shape[0], D_mul_1.shape[2], {D_mul_1.shape[0], D_mul_1.shape[1]});
								}
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_mul_1.upload_2nd(queue);
					rDs_mul_2.upload_2nd(queue);
					rDs_output.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_2, rDs_mul_1.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b2_a2b0

				case Label::ab_ab::a0b2_a2b1:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a0b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b1).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a2b1).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a0b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_b, rDs_a0b2, rDs_a2b1;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul_1, rDs_mul_2;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul1 = D_b * D_a0b2
					// b0b1a0 = b0b1b2 * a0b2
					#pragma omp parallel
					{
						for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a0b2 = tools.get_Ds_ab(Label::ab::a0b2, Aa01, Ab2);
									if(D_a0b2.empty())	continue;

									#pragma omp critical(rDs_mul_1)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a0b2.insert(Aa01, Ab2, D_a0b2);
										rDs_mul_1.insert_1st(Aa01, Ab01, {D_b.shape[0], D_b.shape[1], D_a0b2.shape[0]});
										dim_0.input({D_b.shape[0], D_b.shape[1]}, D_a0b2.shape[0], D_b.shape[2]);
									}
									rDs_b.insert_data(D_b);
									rDs_a0b2.insert_data(D_a0b2);
								} // end for Ab2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a0b2.upload(queue);
					rDs_mul_1.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_b.d_array, rDs_a0b2.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_1.d_array_1,
						rDs_mul_1.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_mul2 = D_a2b1 * D_a
					// b1a0a1 = a2b1 * a0a1a2
					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									// Screen the output pair; Aa2 is summed over, not an output atom.
									if(this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
									if(this->filter_atom->filter_for32(label, Aa01, Ab01, Aa2))	continue;
									const Tensor<Tdata> &D_a2b1 = tools.get_Ds_ab(Label::ab::a2b1, Aa2, Ab01);
									if(D_a2b1.empty())	continue;

									#pragma omp critical(rDs_mul_2)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b1.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, D_a2b1);
										rDs_mul_2.insert_1st(Aa01, Ab01, {D_a2b1.shape[1], D_a.shape[0], D_a.shape[1]});
										dim_1.input(D_a2b1.shape[1], {D_a.shape[0], D_a.shape[1]}, D_a2b1.shape[0]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b1.insert_data(D_a2b1);
								} // end for Aa2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b1.upload(queue);
					rDs_mul_2.upload_1st(queue);
					dim_1.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a2b1.d_array, rDs_a.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_1,
						rDs_mul_2.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul2 * D_mul1
					// a1b0 = b1a0a1 * b0b1a0
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const GPU_Data::Pack &D_mul_1 = rDs_mul_1.find_2nd(Aa01, Ab01);
								if (!D_mul_1.exist)	continue;
								const GPU_Data::Pack &D_mul_2 = rDs_mul_2.find_2nd(Aa01, Ab01);
								if (!D_mul_2.exist)	continue;

								#pragma omp critical(rDs_output)
								{
									rDs_mul_1.insert_2nd(D_mul_1);
									rDs_mul_2.insert_2nd(D_mul_2);
									rDs_output.insert(Aa01, Ab01, {D_mul_2.shape[2], D_mul_1.shape[0]});
									dim_2.input(D_mul_2.shape[2], D_mul_1.shape[0], {D_mul_1.shape[1], D_mul_1.shape[2]});
								}
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_mul_1.upload_2nd(queue);
					rDs_mul_2.upload_2nd(queue);
					rDs_output.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::Trans, GPU_Backend::Trans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_2, rDs_mul_1.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a0b2_a2b1

				case Label::ab_ab::a1b2_a2b0:
				{
					const std::vector<TA >  list_Aa01 = LRI_Cal_Aux::filter_list_map(
						list_Aa01_Da,
						data_wrapper(Label::ab::a1b2).Ds_ab );
					const std::vector<TAC> &list_Aa2 = LRI_Cal_Aux::filter_list_map(
						list_Aa2_Da,
						data_wrapper(Label::ab::a2b0).Ds_ab );
					const std::vector<TAC>  list_Ab01 = LRI_Cal_Aux::filter_list_set(
						list_Ab01_Db,
						data_wrapper(Label::ab::a2b0).index_Ds_ab[0]);
					const std::vector<TAC>  list_Ab2 = LRI_Cal_Aux::filter_list_set(
						list_Ab2_Db,
						data_wrapper(Label::ab::a1b2).index_Ds_ab[0]);

					GPU_Data::Input<TA, TAC, Tdata> rDs_a, rDs_b, rDs_a1b2, rDs_a2b0;
					GPU_Data::Mul<TA, TAC, Tdata> rDs_mul_1, rDs_mul_2;
					GPU_Data::Output<TA, TAC, Tdata> rDs_output;

					Dim_mnk dim_0, dim_1, dim_2;

					// D_mul1 = D_b * D_a1b2
					// a1b0b1 = a1b2 * b0b1b2
					#pragma omp parallel
					{
						for (std::size_t ib01 = 0; ib01 < list_Ab01.size(); ++ib01)
						{
							const TAC &Ab01 = list_Ab01[ib01];
							if(this->filter_atom->filter_for1(label,Ab01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib2=0; ib2<list_Ab2.size(); ++ib2)
							{
								const TAC &Ab2 = list_Ab2[ib2];
								if(this->filter_atom->filter_for2(label,Ab01,Ab2))	continue;
								const Tensor<Tdata> &D_b = tools.get_Ds_ab(Label::ab::b, Ab01, Ab2);
								if(D_b.empty())	continue;
								for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
								{
									const TA &Aa01 = list_Aa01[ia01];
									if(this->filter_atom->filter_for31(label,Aa01,Ab01,Ab2))	continue;
									const Tensor<Tdata> &D_a1b2 = tools.get_Ds_ab(Label::ab::a1b2, Aa01, Ab2);
									if(D_a1b2.empty())	continue;

									#pragma omp critical(rDs_mul_1)
									{
										rDs_b.insert(Ab01.first, {Ab2.first, (Ab2.second - Ab01.second) % period}, D_b);
										rDs_a1b2.insert(Aa01, Ab2, D_a1b2);
										rDs_mul_1.insert_1st(Aa01, Ab01, {D_a1b2.shape[0], D_b.shape[0], D_b.shape[1]});
										dim_0.input(D_a1b2.shape[0], {D_b.shape[0], D_b.shape[1]}, D_a1b2.shape[1]);
									}
									rDs_b.insert_data(D_b);
									rDs_a1b2.insert_data(D_a1b2);
								} // end for Ab2
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_b.upload(queue);
					rDs_a1b2.upload(queue);
					rDs_mul_1.upload_1st(queue);
					dim_0.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::Trans,
						dim_0.m.data(), dim_0.n.data(), dim_0.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a1b2.d_array, rDs_b.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_1.d_array_1,
						rDs_mul_1.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_mul2 = D_a2b0 * D_a
					// a0a1b0 = a0a1a2 * a2b0
					#pragma omp parallel
					{
						for (std::size_t ia01 = 0; ia01 < list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if(this->filter_atom->filter_for1(label,Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ia2=0; ia2<list_Aa2.size(); ++ia2)
							{
								const TAC &Aa2 = list_Aa2[ia2];
								const Tensor<Tdata> &D_a = tools.get_Ds_ab(Label::ab::a, Aa01, Aa2);
								if(D_a.empty())	continue;
								for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
								{
									const TAC &Ab01 = list_Ab01[ib01];
									// Screen the output pair; Aa2 is summed over, not an output atom.
									if(this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
									if(this->filter_atom->filter_for32(label, Aa01, Ab01, Aa2))	continue;
									const Tensor<Tdata> &D_a2b0 = tools.get_Ds_ab(Label::ab::a2b0, Aa2, Ab01);
									if(D_a2b0.empty())	continue;

									#pragma omp critical(rDs_mul_2)
									{
										rDs_a.insert(Aa01, Aa2, D_a);
										rDs_a2b0.insert(Aa2.first, {Ab01.first, (Ab01.second - Aa2.second) % period}, D_a2b0);
										rDs_mul_2.insert_1st(Aa01, Ab01, {D_a.shape[0], D_a.shape[1], D_a2b0.shape[1]});
										dim_1.input({D_a.shape[0], D_a.shape[1]}, D_a2b0.shape[1], D_a.shape[2]);
									}
									rDs_a.insert_data(D_a);
									rDs_a2b0.insert_data(D_a2b0);
								} // end for Aa2
							} // end for Aa01
						} // end for Ab01
					} // end omp parallel

					rDs_a.upload(queue);
					rDs_a2b0.upload(queue);
					rDs_mul_2.upload_1st(queue);
					dim_1.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_1.m.data(), dim_1.n.data(), dim_1.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_a.d_array, rDs_a2b0.d_array,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_1,
						rDs_mul_2.h_array_1.size(), queue);
					GPU_Backend::sync(queue);

					// D_result = D_mul2 * D_mul1
					// a0b1 = a0a1b0 * a1b0b1
					#pragma omp parallel
					{
						for(std::size_t ia01=0; ia01<list_Aa01.size(); ++ia01)
						{
							const TA &Aa01 = list_Aa01[ia01];
							if (this->filter_atom->filter_for1(label, Aa01))	continue;
							#pragma omp for schedule(dynamic) nowait
							for(std::size_t ib01=0; ib01<list_Ab01.size(); ++ib01)
							{
								const TAC &Ab01 = list_Ab01[ib01];
								if (this->filter_atom->filter_for2(label, Aa01, Ab01))	continue;
								const GPU_Data::Pack &D_mul_1 = rDs_mul_1.find_2nd(Aa01, Ab01);
								if (!D_mul_1.exist)	continue;
								const GPU_Data::Pack &D_mul_2 = rDs_mul_2.find_2nd(Aa01, Ab01);
								if (!D_mul_2.exist)	continue;

								#pragma omp critical(rDs_output)
								{
									rDs_mul_1.insert_2nd(D_mul_1);
									rDs_mul_2.insert_2nd(D_mul_2);
									rDs_output.insert(Aa01, Ab01, {D_mul_2.shape[0], D_mul_1.shape[2]});
									dim_2.input(D_mul_2.shape[0], D_mul_1.shape[2], {D_mul_1.shape[0], D_mul_1.shape[1]});
								}
							} // end for Ab01
						} // end for Aa01
					} // end omp parallel

					rDs_mul_1.upload_2nd(queue);
					rDs_mul_2.upload_2nd(queue);
					rDs_output.upload(queue);
					dim_2.upload(queue);

					GPU_Backend::gemmVbatched(
						GPU_Backend::NoTrans, GPU_Backend::NoTrans,
						dim_2.m.data(), dim_2.n.data(), dim_2.k.data(),
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_mul_2.d_array_2, rDs_mul_1.d_array_2,
						GPU_Backend::Type_to_GPU<Tdata>{1}, rDs_output.d_array,
						rDs_output.h_array.size(), queue);
					GPU_Backend::sync(queue);

					rDs_output.download(Ds_result, queue, fac_add_Ds);
				} break; // end case a1b2_a2b0

			default:
				throw std::invalid_argument(std::string(__FILE__)+std::to_string(__LINE__));
		} // end switch(label)
	} // end for label

	LRI_Cal_Aux::destroy_Ds_result(Ds_result);
	#ifdef __MKL_RI
	mkl_set_num_threads(mkl_threads);
	#endif

}	// end LRI::cal_loop3()

}	// end namespace RI

#endif

