#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent.parent
results = root / ("results-mpi" if "--mpi" in sys.argv else "results-single")
results.mkdir(exist_ok=False)
deps = Path("/org/abacus-group/abacususer01/abacus_hse_gpu_experiment/runs/lcao-hse/exx-device-20261018-3")
records = []

def run(name, command, timeout=1200):
    start = time.monotonic()
    with (results / (name + ".log")).open("w") as log:
        log.write("$ " + " ".join(map(str, command)) + "\n")
        log.flush()
        process = subprocess.run(list(map(str, command)), cwd=root, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=timeout)
    item = dict(name=name, command=list(map(str, command)), returncode=process.returncode,
                elapsed_seconds=time.monotonic()-start)
    records.append(item)
    (results / "commands.json").write_text(json.dumps(records, indent=2)+"\n")
    print(name, item["returncode"], round(item["elapsed_seconds"], 3), flush=True)
    return process.returncode

identity = {}
for version in ("before", "after"):
    source = root / ("source-" + version)
    identity[version] = {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest()
                         for path in sorted(source.rglob("*")) if path.is_file()}
(results / "source-sha256.json").write_text(json.dumps(identity, indent=2)+"\n")
run("hardware", ["nvidia-smi"])
run("compiler", ["g++", "--version"])
run("cuda", ["nvcc", "--version"])
run("mpi", ["mpirun", "--version"])

for version in ("before", "after"):
    build = root / ("build-" + version)
    if "--mpi" not in sys.argv:
        rc = run(version + "-configure", ["cmake", "-S", root / "source-after/unittests/gpu_regressions",
            "-B", build, "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON",
            "-DENABLE_MPI_REGRESSIONS=ON", "-DLIBRI_ROOT="+str(root/("source-"+version)),
            "-DLIBCOMM_ROOT="+str(deps/"build/hse-deps/libcomm"),
            "-DCEREAL_ROOT="+str(deps/"build/hse-deps/cereal-install"),
            "-DDDLA_ROOT="+str(deps/"install/ddla")])
        if rc:
            raise SystemExit(rc)
        rc = run(version + "-build", ["cmake", "--build", build, "--parallel", "2", "--verbose"])
        if rc:
            raise SystemExit(rc)
    select = ["-R", "_mpi2$"] if "--mpi" in sys.argv else ["-E", "_mpi2$"]
    run(version + "-ctest", ["ctest", "--test-dir", build, "--verbose", "--output-on-failure",
                             "--output-junit", results/(version+"-junit.xml"), *select], 1800)
    for filename in ("gpu_regressions_real", "gpu_regressions_complex"):
        binary = build / filename
        (results / (version + "-" + filename + ".sha256")).write_text(
            hashlib.sha256(binary.read_bytes()).hexdigest() + "  " + filename + "\n")
    run(version + "-libraries", ["ldd", build / "gpu_regressions_real"])

assert all(r["returncode"] == 0 for r in records if r["name"] != "before-ctest"), records
print("Completed; original-header CTest failures are retained as baseline evidence.", flush=True)
