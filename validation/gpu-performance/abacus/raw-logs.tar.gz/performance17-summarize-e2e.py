from pathlib import Path
import json
import statistics
import sys

root = Path(sys.argv[1])
rows = json.loads((root / 'measurements.json').read_text())
rows = [row for row in rows if not row['warmup']]
assert len(rows) == 18
checks = json.loads((root / 'comparisons.json').read_text())
assert len(checks) == 18 and all(check['passed'] for check in checks)

def value(row, key):
    if key == 'wall_seconds':
        return row[key]
    return row['timing'][key]['seconds']

summary = []
metrics = ['wall_seconds', 'Driver.atomic_world', 'Exx_LRI.cal_exx_elec',
           'Exx_LRI.cal_exx_force']
for material in ['si8', 'si64']:
    for variant in ['master', 'pr17', 'fixed']:
        selected = [row for row in rows if row['material'] == material
                    and row['variant'] == variant]
        assert len(selected) == 3
        record = dict(material=material, variant=variant,
                      outer_steps=[row['outer_steps'] for row in selected],
                      inner_steps=[row['inner_steps'] for row in selected],
                      gpu_peak_process_mib=[row['gpu_peak_process_mib'] for row in selected],
                      metrics={})
        for metric in metrics:
            seconds = [value(row, metric) for row in selected]
            paired = []
            for row in selected:
                base = next(r for r in rows if r['material'] == material
                            and r['variant'] == 'master'
                            and r['repetition'] == row['repetition'])
                paired.append(value(base, metric) / value(row, metric))
            record['metrics'][metric] = dict(median_seconds=statistics.median(seconds),
                min_seconds=min(seconds), max_seconds=max(seconds), samples_seconds=seconds,
                paired_speedup_median=statistics.median(paired), paired_speedups=paired)
        summary.append(record)

result = dict(summary=summary, measurements=18, warmup_runs=3,
              numerical_checks=checks,
              max_energy_error_ev=max(c['energy_error_ev'] for c in checks),
              max_force_error_ev_angstrom=max(c['max_force_error_ev_angstrom'] for c in checks),
              all_outer_counts_equal=all(c['same_outer_steps'] for c in checks),
              all_inner_counts_equal=all(c['same_inner_steps'] for c in checks))
(root / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print('| Case | Version | Wall median [min, max] s | EXX electronic median s | EXX force median s |')
print('|---|---|---:|---:|---:|')
for row in summary:
    m = row['metrics']; wall = m['wall_seconds']
    print(f"| {row['material']} | {row['variant']} | {wall['median_seconds']:.3f} "
          f"[{wall['min_seconds']:.3f}, {wall['max_seconds']:.3f}] | "
          f"{m['Exx_LRI.cal_exx_elec']['median_seconds']:.3f} | "
          f"{m['Exx_LRI.cal_exx_force']['median_seconds']:.3f} |")
print(json.dumps({k:v for k,v in result.items() if k not in {'summary','numerical_checks'}},indent=2))
