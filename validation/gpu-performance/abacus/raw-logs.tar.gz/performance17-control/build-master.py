from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time

root = Path(__file__).resolve().parent.parent
reference = root.parent / "lcao-hse/pr8169-release-preparation-20261024"
old_build = reference / "abacus-build"
old_ddla = root.parent / "lcao-hse/exx-device-20261018-3/install/ddla"
new_ddla = old_ddla
out = root / "performance17-abacus-master"
out.mkdir(exist_ok=False)
new_headers = root / "master/include"
records = json.loads((old_build / "compile_commands.json").read_text())
selected = []
substitutions = {}

for record in records:
    command = shlex.split(record["command"])
    if "-o" not in command:
        continue
    old_object = (Path(record["directory"]) / command[command.index("-o") + 1]).resolve()
    dependency = Path(str(old_object) + ".d")
    if not dependency.exists():
        continue
    text = dependency.read_text()
    if str(reference / "source/include/RI/") not in text:
        continue
    index = len(selected)
    new_object = out / f"{index:02d}-{old_object.name}"
    command[command.index("-o") + 1] = str(new_object)
    for old, new in [(reference / "source/include", new_headers), (old_ddla / "include", new_ddla / "include")]:
        option = "-I" + str(old)
        assert command.count(option) == 1, (record["file"], option)
        command[command.index(option)] = "-I" + str(new)
    command += ["-MD", "-MF", str(new_object)+".d"]
    substitutions[old_object] = new_object
    selected.append(dict(original=record, original_object=str(old_object),
                         command=command, index=index))
assert len(selected) >= 40, len(selected)
(out / "compile-selection.json").write_text(json.dumps(selected, indent=2)+"\n")

def compile_one(record):
    i = record["index"]
    command = record["command"]
    (out / f"compile-{i:02d}.command.txt").write_text(shlex.join(command)+"\n")
    print("COMPILE", record["original"]["file"], flush=True)
    start = time.monotonic()
    with (out / f"compile-{i:02d}.log").open("wb") as log:
        result = subprocess.run(command, cwd=record["original"]["directory"], stdout=log, stderr=subprocess.STDOUT)
    (out / f"compile-{i:02d}.result.json").write_text(json.dumps(dict(
        exit_code=result.returncode, elapsed_seconds=time.monotonic()-start), indent=2)+"\n")
    assert result.returncode == 0, record["original"]["file"]

with ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(compile_one, selected))

link_dir = old_build / "source"
command = shlex.split((link_dir / "CMakeFiles/abacus_std_gpu.dir/link.txt").read_text())
binary = out / "abacus_std_gpu"
command[command.index("-o")+1] = str(binary)
replaced = set()
for i, argument in enumerate(command):
    if argument.startswith("-Wl,--dependency-file="):
        command[i] = "-Wl,--dependency-file=" + str(out/"link.d")
    elif argument.startswith("@"):
        objects = shlex.split((link_dir / argument[1:]).read_text())
        for j, name in enumerate(objects):
            absolute = (link_dir / name).resolve()
            if absolute in substitutions:
                objects[j] = str(substitutions[absolute])
                replaced.add(absolute)
        response = out / "objects.rsp"
        response.write_text(shlex.join(objects)+"\n")
        command[i] = "@" + str(response)
    else:
        command[i] = argument.replace(str(old_ddla), str(new_ddla))
assert replaced == set(substitutions)
(out / "link.command.txt").write_text(shlex.join(command)+"\n")
with (out / "link.log").open("wb") as log:
    result = subprocess.run(command, cwd=link_dir, stdout=log, stderr=subprocess.STDOUT)
(out / "link.exit-code.txt").write_text(str(result.returncode)+"\n")
assert result.returncode == 0
with (out / "version.log").open("wb") as log:
    subprocess.run([str(binary), "--version"], stdout=log, stderr=subprocess.STDOUT, check=True)
print("PERFORMANCE BASELINE BUILD PASSED", flush=True)
