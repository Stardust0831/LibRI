# LibRI PR #17 GPU timing evidence

This compact bundle preserves the full original configure, compile and runtime logs, every timing sample, output comparison metrics, commands, affinity/GPU identity, source and binary hashes, and scheduler accounting for the two measured workloads. The first harness compilation failure is retained as well. Logs have not been excerpted or rewritten.

The successful matrices contained 90 independent process runs, 450 measured steady calls, and 180 comparisons of complete output tensors covering 16,711,680 scalar values. All comparisons passed. The original raw archive, including full first/last binary tensor dumps, remains separately available as `performance17-micro-evidence.tar.gz`, SHA256 `e3006300ec8342ce9321162d7ecf1361b596fe77b0a325a7289f817be8fe0ee4`. This reduced bundle omits those dumps and compiled cache files. `omitted-binary-outputs-sha256.json` records the exact relative path, byte count and SHA256 of each omitted file; the pilot dumps are indexed too.

Key records:

- `performance17-micro-results-2153583/`: the complete 16-atom matrix, including 1/4 physical CPU cores and real/complex tensors.
- `performance17-micro-large-results-2153717/`: the complete 24-atom confirmation using four physical cores; identical Release executables were reused by verified SHA256.
- Each successful result directory contains `results.json`, `summary.json`, `comparisons.json`, `table.md`, per-run `samples.csv`, and full `stdout.log` files.
- `performance17-micro-results-2153442/`: the initial driver compilation failure, before any timings. Its use of valarray member begin/end was corrected before both successful matrices; the original control archive is preserved.
- `performance17-micro-accounting.txt`: both measurement jobs completed with exit status 0.
- `performance17-control/source-manifest.json` and the included source snapshots identify all tested LibRI headers; the fixed version adds the included three-file patch to the recorded PR head.

The driver measures actual GPU `cal_loop3` execution for four EXX contractions, with fresh D values each iteration and stable C/V. CUDA synchronization brackets each timer. Five measured calls follow one cold call and two warmups in each process. Three rotated process-run rounds were used for every configuration. Full details and interpretation are in the accompanying performance report; these contraction timings are not whole-application timings.
