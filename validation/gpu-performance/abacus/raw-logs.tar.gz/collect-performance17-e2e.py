from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

root = Path.cwd()
out = root / 'performance17-e2e-results-v3'
assert (out / 'comparisons.json').exists(), 'Wait for the complete measured matrix'
rows = json.loads((out / 'measurements.json').read_text())
comparisons = json.loads((out / 'comparisons.json').read_text())
assert len(rows) == 21 and len(comparisons) == 18
assert all(row['passed'] for row in comparisons)
identities = json.loads((out / 'binaries.json').read_text())
assert len({record['ddla_sha256'] for record in identities.values()}) == 1
for record in identities.values():
    path = Path(record['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], path
manifest = json.loads((root / 'performance17-e2e-control-v3/source-manifest.json').read_text())
for path, digest in manifest['files'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == digest, path

case_identity = []
for row in rows:
    case = out / row['directory']
    info = (case / 'OUT.bench/INPUT.info').read_text()
    assert re.search(r'(?m)^\s*device_exx\s+gpu(?:\s|$)', info)
    assert row['gpu_peak_process_mib'] > 0
    hashes = {name: hashlib.sha256((case / name).read_bytes()).hexdigest()
              for name in ['INPUT', 'STRU', 'KPT']}
    case_identity.append(dict(case=row['directory'], input_sha256=hashes,
                              binding=json.loads((case / 'binding-0.json').read_text()),
                              input_assets=json.loads((case / 'input-assets.json').read_text())))
for material in ['si8', 'si64']:
    selected = [item for item in case_identity if item['case'].startswith(material + '-')]
    assert len({json.dumps(item['input_sha256'], sort_keys=True) for item in selected}) == 1
    assert len({json.dumps(item['binding']['cpu_affinity']) for item in selected}) == 1
    assert len({json.dumps(item['input_assets'], sort_keys=True) for item in selected}) == 1
(out / 'case-identity.json').write_text(json.dumps(case_identity, indent=2) + '\n')

accounting = subprocess.check_output([
    'sacct', '-j', '2152251,2153448,2153643',
    '--format=JobID,State,ExitCode,Elapsed,AllocTRES%80', '-P'], text=True)
(root / 'performance17-e2e-accounting.txt').write_text(accounting)
reference = root.parent / 'lcao-hse/pr8169-release-preparation-20261024'
(root / 'performance17-abacus-source-manifest.json').write_bytes((reference / 'manifest.json').read_bytes())

trees = [
    'performance17-control', 'performance17-e2e-control-v2', 'performance17-e2e-control-v3',
    'performance17-e2e-results', 'performance17-e2e-results-v2',
    'performance17-e2e-results-v3', 'performance17-abacus-master',
]
files = set()
for tree in trees:
    files.update(path for path in (root / tree).rglob('*')
                 if path.is_file() and not path.is_symlink())
files.update(root.glob('performance17-e2e-*.log'))
files.update(root.glob('performance17-e2e-control*.tar.gz'))
files.update(root / name for name in [
    'performance17-e2e-accounting.txt', 'performance17-abacus-source-manifest.json',
    'performance17-summarize-e2e.py', 'collect-performance17-e2e.py',
    'control17/modules.sh',
])
for build in ['abacus-build', 'suggestions17-abacus-build']:
    files.update(path for path in (root / build).rglob('*')
                 if path.is_file() and not path.is_symlink()
                 and path.suffix in {'.log', '.json', '.txt', '.rsp', '.d'})

index, excluded = {}, []
archive = root / 'performance17-e2e-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(files):
        if path.suffix == '.pyc':
            continue
        with path.open('rb') as stream:
            magic = stream.read(4)
        relative = str(path.relative_to(root))
        if magic == b'\x7fELF' or path.suffix == '.o':
            excluded.append(relative)
            continue
        index[relative] = dict(bytes=path.stat().st_size,
                               sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        tar.add(path, arcname=relative, recursive=False)
    index_path = root / 'performance17-e2e-file-index.json'
    index_path.write_text(json.dumps(dict(files=index, excluded_objects=excluded), indent=2) + '\n')
    tar.add(index_path, arcname=index_path.name)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(root / 'performance17-e2e-evidence.sha256').write_text(digest + '  ' + archive.name + '\n')
print('Archived', len(index), 'files;', archive.stat().st_size, 'bytes;', digest)
