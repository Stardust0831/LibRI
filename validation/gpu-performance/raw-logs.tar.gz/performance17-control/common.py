from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).resolve().parent.parent
control = Path(__file__).resolve().parent

def verify_sources():
    manifest = json.loads((control / 'source-manifest.json').read_text())
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
    return manifest

def setup(out, threads=6):
    out.mkdir(exist_ok=False)
    allowed = sorted(os.sched_getaffinity(0))
    topology = subprocess.check_output(['lscpu', '-p=CPU,CORE,SOCKET'], text=True)
    chosen, seen = [], set()
    for line in topology.splitlines():
        if line.startswith('#'):
            continue
        cpu, core, socket = map(int, line.split(','))
        if cpu in allowed and (socket, core) not in seen:
            chosen.append(cpu)
            seen.add((socket, core))
    assert len(chosen) >= threads, (chosen, threads)
    mapping = dict(allocated_cpus=allowed, rank_cpus=[chosen[:threads]])
    mapping_path = out / 'mapping.json'
    mapping_path.write_text(json.dumps(mapping, indent=2) + '\n')
    os.environ.update(BENCH_MAPPING_FILE=str(mapping_path), BENCH_RANKS='1',
                      OMP_NUM_THREADS=str(threads), OPENBLAS_NUM_THREADS='1',
                      MKL_NUM_THREADS='1', OMP_PROC_BIND='close', OMP_DYNAMIC='false')
    environment = {
        'source_manifest': verify_sources(),
        'slurm_job_id': os.environ.get('SLURM_JOB_ID'),
        'mapping': mapping,
        'environment': {k: v for k, v in os.environ.items()
                        if k.startswith(('OMP_', 'CUDA_', 'SLURM_', 'OPENBLAS_', 'MKL_'))},
    }
    (out / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
    for name, cmd in [('gpu', ['nvidia-smi', '-q']), ('topology', ['nvidia-smi', 'topo', '-m']),
                      ('compiler', ['mpicxx', '--version'])]:
        p = subprocess.run(cmd, text=True, capture_output=True)
        (out / (name + '.log')).write_text(p.stdout + p.stderr)

def binary_identity(binary):
    linked = subprocess.check_output(['ldd', str(binary)], text=True)
    assert 'not found' not in linked
    ddla = root.parent / 'lcao-hse/exx-device-20261018-3/install/ddla/lib/libddla.so'
    assert str(ddla.parent) in linked
    return dict(path=str(binary), sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                ldd=linked, ddla_sha256=hashlib.sha256(ddla.resolve().read_bytes()).hexdigest())
