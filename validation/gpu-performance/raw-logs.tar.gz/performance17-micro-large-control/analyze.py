#!/usr/bin/env python3
"""Summarize fresh-process runs without treating intra-process calls as independent runs."""
from pathlib import Path
import json
import statistics
import sys

out = Path(sys.argv[1]).resolve()
results = json.loads((out / 'results.json').read_text())
comparisons = json.loads((out / 'comparisons.json').read_text())
table = []
for threads in [4]:
    for scalar in ['real', 'complex']:
        baseline = {x['round']: x for x in results if x['threads'] == threads and x['scalar'] == scalar and x['source'] == 'master'}
        for source, resident in [('master', False), ('pr17', False), ('pr17', True), ('pr17-suggestions', False), ('pr17-suggestions', True)]:
            rows = [x for x in results if x['threads'] == threads and x['scalar'] == scalar and x['source'] == source and x['resident'] == resident]
            assert len(rows) == 3
            medians = [x['median_seconds'] for x in rows]
            ratios = [baseline[x['round']]['median_seconds'] / x['median_seconds'] for x in rows]
            table.append(dict(threads=threads, scalar=scalar, source=source, resident=resident,
                              medians_seconds=medians, median_of_medians_seconds=statistics.median(medians),
                              median_range_seconds=[min(medians), max(medians)],
                              within_run_all_samples_range_seconds=[min(x['min_seconds'] for x in rows), max(x['max_seconds'] for x in rows)],
                              cold_seconds=[x['cold_seconds'] for x in rows],
                              median_cold_seconds=statistics.median(x['cold_seconds'] for x in rows),
                              paired_speedups=ratios, median_paired_speedup=statistics.median(ratios),
                              peak_process_gpu_mib=max(x['peak_process_gpu_mib'] or 0 for x in rows)))
summary = dict(groups=table, runs=len(results), measured_calls=sum(len(x['steady_seconds']) for x in results),
               full_output_comparisons=len(comparisons), compared_elements=sum(x['elements'] for x in comparisons),
               max_cross_absolute=max(x['max_absolute'] for x in comparisons),
               max_cross_scaled=max(x['max_scaled'] for x in comparisons),
               max_linear_absolute=max(x['max_linear_absolute'] for x in results),
               max_linear_scaled=max(x['max_linear_scaled'] for x in results))
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
lines = ['| Threads | Type | Version | Residency | Steady median (s) | 3-run median range (s) | Paired speedup | Cold median (s) |',
         '|---:|---|---|---|---:|---:|---:|---:|']
for row in table:
    lines.append('| {threads} | {scalar} | {source} | {resident} | {median_of_medians_seconds:.6f} | {low:.6f}–{high:.6f} | {median_paired_speedup:.3f}× | {median_cold_seconds:.6f} |'.format(
        **row, low=row['median_range_seconds'][0], high=row['median_range_seconds'][1]))
(out / 'table.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
print(json.dumps({k:v for k,v in summary.items() if k != 'groups'}, indent=2))
